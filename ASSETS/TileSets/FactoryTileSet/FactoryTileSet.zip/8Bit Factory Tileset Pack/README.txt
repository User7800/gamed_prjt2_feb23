A small collection of tiles perfect for creating an 8bit syled factory level.  These are remade from a mock-up screenshot as a small token of gratitude for 500 followers on twitter.  (https://twitter.com/SeaEgull). Please note that these tile's don't have equal aspect ratio's but otherwise are the same pixel count and size.

If needed the tiles can be seperated into equal parts using the raw spreadsheet file, but some larger pieces such as the window may not seperate as nicely.

These assets are licensed as per (CC BY 4.0)
Made by SeaEgull Games